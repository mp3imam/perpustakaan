###Content

This menu is used to change the appearance of the Senayan application content. By default, views that already exist and can be modified in this menu are: 
- Homepage info, located at the front of the OPAC [displayed when “Home” is clicked ], 
- Welcome to Admin page [the initial display when entering the Admin menu (Senayan Management Console)],
- Help On Usage [accessed from the OPAC], and 
- Library Information [ also accessed from the OPAC].

Consider a path created for the new content that is 'librarian'. To display this content with librarians path, then we need to write the url:

http://localhost/slims5_meranti/index.php?p=librarian

We can create the navigation to this URL in the OPAC by editing the template.
