###Custom Recapitulations

This menu displays the recapitulation of:
- Titles, based on Classification, 
- GMD, 
- Collection Type or Language. 

This option can be set by selecting the recapitulation filter available. Senayan also supports recap for classifications not based on decimal numbers. For example, REF for reference.

Custom Recapitulation - “Print Current Page” provides the facility to print reports, and "Export to spreadsheet format" to place the report in a spreadsheet.
