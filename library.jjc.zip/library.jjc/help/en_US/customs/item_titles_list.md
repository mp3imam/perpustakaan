###Items Title List

Contains reports/lists of copies of titles held by the library. In this menu there is a facility to sort and print, as well as a collection of desired filters. In this menu, filtering can also be done by writing the Title/ISBN, or by other filters. You do this by clicking "Show More Filter Options". Available filters are: 
- Title/ISBN, 
- Item Code, 
- Classification, 
- Collection Type, 
- Item Status, 
- Location. 

This filter facilities can be hidden by clicking "Hide More Filter Options."
