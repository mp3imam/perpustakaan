###Visitor Statistic (by day)

This is a report based on the number of visitors per weekday.
