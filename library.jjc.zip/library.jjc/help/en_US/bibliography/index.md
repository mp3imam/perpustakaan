#### Add new bibliography
<hr>
This menu is used to add a new bibliography. To do it, click on the “Add New Bibliography”. Then you needs to add a new item.
