### Modul
<hr>
Anda dapat melihat modul, mencari module, mengubah, menghapus dan menambah module. Untuk menambah module, folder modul yang sudah ada diletakkan dalam folder admin/modules/. Kemudian klik Add New Modules, isikan informasi modul baru, yaitu:
- Module Name (nama modul),
- Module Path (path/letak modul),
- Module Description (deskripsi singkat modul), kemudian klik Save.
