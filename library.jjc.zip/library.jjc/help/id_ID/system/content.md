### Konten
<hr>
Menu ini digunakan untuk mengubah tampilan content aplikasi senayan. Secara default, tampilan yang sudah ada dan dapat dimodifikasi dalam menu ini adalah:
- Homepage info, terletak di bagian depan OPAC
- Lisensi SLiMS
- Tentang SLiMS
- Model Pengembangan Opensource
- Modul yang tersedia
- Welcome to admin page,
- Help on usage, pada OPAC.
- Library Information, juga ada pada OPAC.

Untuk memanggil content, perlu ditentukan path unik. Misalnya 'pustakawan', maka untuk menampilkannya dengan memanggil: http://alamatslims/index.php?p=pustakawan
