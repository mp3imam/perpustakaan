####Daftar Eksemplar

Menu ini digunakan untuk melihat item eksemplar yang terdapat dalam database SLIMS.
Informasi yang ada dalam menu ini adalah:
- Item Code,
- Title,
- Type,
- Location,
- Class,
- Last Update.

Dengan menu ini dapat pula dilakukan proses edit dan menghapus nomor item.

Berikut langkah untuk mengedit atau menghapus item:
- Cari item yang akan diubah/hapus dengan mengetikkan judul atau item code pada kolom Search, kemudian klik Search
- Setelah ditemukan, check box data yang akan di hapus lalu klik Delete Selected Data atau klik icon edit (sebelah kiri judul) untuk mengedit .
- Muncul tampilan data item yang masih di disable. Aktifkan mode edit dengan klik icon Edit di pojok kanan bawah atau pojok kanan atas.
- Edit bagian yang perlu, kemudian klik Save Change.
