#### Import data anggota
 <hr>
Anda dapat melakukan proses import dengen fitur ini. File yang diimport adalah file .csv dengan urutan kolom sesuai format yang dapat diterima oleh SLiMS. Urutan kolom dalam .csv tersebut adalah: 
- No anggota
- Nama
- Gender 
- Jenis anggota
- Email
- Alamat
- Kodepos
- Institusi asal
- 
- File gambar (jika ada)
- No Identitas (KTP)
- Telepon
- Fax
- Tanggal sejak anggota
- Tanggal mendaftar
- Tanggal kadaluarsa
- Tanggal lahir
- Catatan
- Tangggal input
- Terakhir update