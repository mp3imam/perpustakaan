####Tipe Keanggotaan
 <hr>
Merupakan definisi jenis keanggotaan. Di dalam jenis keanggotaan ini di tetapkan:
- Loan Limit (batas eksemplar peminjaman),
- Loan Periode (lama pinjam),
- Reserve (pemesanan),
- Reserve Limit (batas eksemplar pemesanan),
- Membership Periode (lama keanggotaan),
- Reborrow Limit (batas perpanjangan),
- Fine Each Day (denda perhari), dan
- Overdue Grace Periode (Toleransi keterlambatan). 
