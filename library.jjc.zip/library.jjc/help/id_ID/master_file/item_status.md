####Master File / Status Eksemplar
<hr>
Gunakan fitur ini untuk mengisi status eksemplar.
contoh: sedang diperbaiki, sedang dipinjam, sedang dipesan

Pada Item Status ini diisikan:  Item Status Code, Item Status Name, dan Rules.
Ada dua pilihan dalam Rules:
- No Loan Transaction (item tidak bisa dipinjam, misal: koleksi digital) 
- Skipped by Stock Take (tidak diproses dalam Stock Take)
