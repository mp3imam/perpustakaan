####Master File / Kala Terbit
<hr>
Gunakan fitur ini untuk mengisi daftar kala/frekwensi terbit terbitan berseri.
Contoh : Mingguan, Bulanan, Dua Mingguan, Harian
