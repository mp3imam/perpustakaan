### Daftar anggota
<hr>
Berisi laporan/daftar anggota perpustakaan. Dalam menu ini terdapat fasilitas untuk mengurutkan dan mencetak. Selain itu, terdapat pula fasilitas filter, yaitu: berdasar Membership Type, Member ID/Member Name, Gender, Address, Register Date From, Register Date Until.
Fitur ini juga mengediakan fasilitas unduh file dalam bentuk spreadsheet. File dapat didapatkan dengan klik “Export to spreadsheet format”.