<script>
	alert(<?php echo $_POST['value']; ?>);
	window.location.href = 'index.php';
</script>